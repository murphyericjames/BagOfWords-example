The main document 'Lab1.py' is written in Python
To call said program from command shell type 'python Lab1.py'

No other commands are necessary as all cvs files are defined within the main program file Lab1.py

The Lab1.py file and all other necessary python files containing relevant functions, i.e. Accuracy.py, NBAnalysis.py, ClassPrior.py, and ConditionalProb.py, should be located in the parent folder of the folder containing the cvs files, i.e. parent folder of ./20newsgroups/.

To run in IPython or Jupyter notebook call using the magic command %run as '%run Lab1.py'

All relevant statistics are printed out to screen

